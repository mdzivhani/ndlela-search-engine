--
-- PostgreSQL database dump
--

\restrict gqC558K6I0FOnOIBH3cruWIoR1pHzqdnAbVFWoFi17MzZ1ruVJE5C2nHNNzFAsN

-- Dumped from database version 15.15 (Debian 15.15-1.pgdg13+1)
-- Dumped by pg_dump version 15.15 (Debian 15.15-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


ALTER TABLE public."__EFMigrationsHistory" OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id text NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    phone character varying(50),
    location character varying(255),
    city character varying(100),
    province character varying(100),
    profile_picture text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, password_hash, name, phone, location, city, province, profile_picture, created_at, updated_at) FROM stdin;
user-1764172140052	test@example.com	$2b$10$yA19prH8jDhhIN9pSwtc0uOMfZ1fTrcTjFvzlZnbCljkhZSU.Wsf2	Test User	\N	\N	\N	\N	\N	2025-11-26 15:49:00.089438	2025-11-26 15:49:00.089438
user-1764676058042	test_1764676058@example.com	$2b$10$ySOp.G.XGtV2HGKkGGfuj.STV39xqcgZDv9G5k2SzNL.VhhrV93wi	Test User	\N	\N	\N	\N	\N	2025-12-02 11:47:38.076273	2025-12-02 11:47:38.076273
user-1764676101759	test_1764676101@example.com	$2b$10$OOYizaxOFl3UnNfr9BjkIeaRVaCbhNl.Q5dqiTqRFX3iTr8xgU6fm	Test User	\N	\N	\N	\N	\N	2025-12-02 11:48:21.795619	2025-12-02 11:48:21.795619
user-1764677282891	Lallydzi@gmail.com	$2b$10$ijF0u5hzGQJIsfLDfuQHJetA724IYj8c5Wv8jHNkir8zk2mabwKjK	Mulalo Dzivhani	\N	\N	\N	\N	\N	2025-12-02 12:08:02.925551	2025-12-02 13:25:43.921866
\.


--
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict gqC558K6I0FOnOIBH3cruWIoR1pHzqdnAbVFWoFi17MzZ1ruVJE5C2nHNNzFAsN

