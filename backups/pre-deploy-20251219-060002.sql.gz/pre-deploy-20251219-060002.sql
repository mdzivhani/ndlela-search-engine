--
-- PostgreSQL database dump
--

\restrict G0xNxGHh0mnhGWqDGKmtQYtlV1Q9S3D1GYRjAsAw176OqN1a6QAbvo8LXwBHJku

-- Dumped from database version 15.15 (Debian 15.15-1.pgdg13+1)
-- Dumped by pg_dump version 15.15 (Debian 15.15-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


ALTER TABLE public."__EFMigrationsHistory" OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id text NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    phone character varying(50),
    location character varying(255),
    city character varying(100),
    province character varying(100),
    profile_picture text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, password_hash, name, phone, location, city, province, profile_picture, created_at, updated_at) FROM stdin;
user-1764172140052	test@example.com	$2b$10$yA19prH8jDhhIN9pSwtc0uOMfZ1fTrcTjFvzlZnbCljkhZSU.Wsf2	Test User	\N	\N	\N	\N	\N	2025-11-26 15:49:00.089438	2025-11-26 15:49:00.089438
user-1764676058042	test_1764676058@example.com	$2b$10$ySOp.G.XGtV2HGKkGGfuj.STV39xqcgZDv9G5k2SzNL.VhhrV93wi	Test User	\N	\N	\N	\N	\N	2025-12-02 11:47:38.076273	2025-12-02 11:47:38.076273
user-1764676101759	test_1764676101@example.com	$2b$10$OOYizaxOFl3UnNfr9BjkIeaRVaCbhNl.Q5dqiTqRFX3iTr8xgU6fm	Test User	\N	\N	\N	\N	\N	2025-12-02 11:48:21.795619	2025-12-02 11:48:21.795619
user-1764677282891	Lallydzi@gmail.com	$2b$10$ijF0u5hzGQJIsfLDfuQHJetA724IYj8c5Wv8jHNkir8zk2mabwKjK	Mulalo Dzivhani	\N	\N	\N	\N	\N	2025-12-02 12:08:02.925551	2025-12-02 13:25:43.921866
user-1766117452383	smoke.test+1766117452@example.com	$2b$10$ZvpWMwpYW6HFqoWqbBRspepF8mteBdXJBilOXZ38K1XFf5A8NJ6bS	Smoke Tester	\N	\N	\N	\N	\N	2025-12-19 04:10:52.420532	2025-12-19 04:10:52.420532
user-1766120382747	test404@example.com	$2b$10$We0fu.wcpikforZqHecLWezkmKVFbG6X1Awp7nEt3KOOvW.Ah6lmG	Test User	\N	\N	\N	\N	\N	2025-12-19 04:59:42.78451	2025-12-19 04:59:42.78451
user-1766120400485	test404b@example.com	$2b$10$P8n47LmUpN0AVJ/6bGzWNOX6y5D3KkK9ZLe.HB4UgZvGkXiQ7vpIC	Test User	\N	\N	\N	\N	\N	2025-12-19 05:00:00.521644	2025-12-19 05:00:00.521644
user-1766121014379	testfix@example.com	$2b$10$qR4v62Zl/pNbEZ5yecF4UOZl3O6M0r5YbK/mJgROTyd.zHgfiIKge	Fix User	\N	\N	\N	\N	\N	2025-12-19 05:10:14.412984	2025-12-19 05:10:14.412984
user-1766121185374	newuser@example.com	$2b$10$9r5lzqFru2O8NyTjXZRQY.pnN9qB6zwQJqHnL3ehBbqhl/E7Ojway	New User	\N	\N	\N	\N	\N	2025-12-19 05:13:05.408369	2025-12-19 05:13:05.408369
user-1766122117037	Testing@gmail.com	$2b$10$A8RgYw2j5sqiuaXMRmqGu.7f4O5t0DDsEhFjA9g3.FsE4zFpJzp72	John Doe	\N	\N	\N	\N	\N	2025-12-19 05:28:37.071425	2025-12-19 05:28:37.071425
user-1766122224331	final-test@example.com	$2b$10$gKGrqQsJP34h2q1N7HAYZeQqcT6fj4Si3D/FXqCE5Ci5GUNW75Hde	Final Test	\N	\N	\N	\N	\N	2025-12-19 05:30:24.365142	2025-12-19 05:30:24.365142
\.


--
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict G0xNxGHh0mnhGWqDGKmtQYtlV1Q9S3D1GYRjAsAw176OqN1a6QAbvo8LXwBHJku

